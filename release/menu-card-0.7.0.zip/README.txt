=== Menu Card ===
Contributors: furqan Khanzada, haiderali3010
Tags: menu, card, menu card, restaurants menu card
Requires at least: 3.0
Tested up to: 3.6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Menu Card Lets you build menu card of restaurants, with a shortcode.

== Description ==

Menu Card can manage multiple menus using shortcode. you can also categorised menu by category and can set price also you can toggle link option.

= How To Use =

Simply place **[menucard]** in your posts/pages for displaying all categories of menu and for specific category use **[menucard category="CATEGORY_SLUG,CATEGORY_SLUG"]**. [Demo](http://menu.appbakerz.com/)


You can set the following values in options page or use the attribute to override the values from options page:

* **Price**: Price of menu item.
* **Link**: It should be link with menu card's item detail page or not or you want to use custom url.
* **Custom Url** Input any url that you want to open when click on menu card item. for this (link) should be *custom url*.


== Installation ==

1. Copy the zip file to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Screenshots ==

1. screenshot-1.png


== Changelog ==

= 0.7.0 =
Fixed edit menu category issue. This is major change you will lost all previous categories.

= 0.6.0 =
Initial version.