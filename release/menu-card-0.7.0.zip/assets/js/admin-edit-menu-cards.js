/**
 * Admin javascript for menu-cards Custom Post.
 *
 * @package Menu_Card
 * @author  Furqan Khanzada <furqan.khanzada@gmail.com>
 * @license   GPL-2.0+
 * @link      https://wordpress.org/plugins/menu-card/
 */

jQuery(function ($) {
	"use strict";
	// Place your JavaScript here
  console.log("js file included: ", "admin-custom-post-menu-cards.js");
});